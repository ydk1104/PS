algorithms
==========
set of frequently used algorithms in algorithm problem solving contest.

license
==========

- 소스코드의 재배포 및 공개를 할 때는 이 라이선스를 함께 포함하여야 하고 저작권자를 밝혀야 한다.
- 단, 온라인 저지나 프로그래밍 대회 등에 활용할 때는 라이선스 표시를 생략할 수 있다.
- 바이너리 형식으로 배포할 때는 아무런 제약이 없다.
- 이 소프트웨어는 어떠한 보증도 제공하지 않는다.
- 저작권자와 기여자는 이 소프트웨어를 사용으로 발생하는 직간접적인 손해, 우발적인 손해 등 어떠한 손해에 대해서도 책임지지 않는다.
- 따로 허가를 받지 않는 한, 기여자의 이름이나 아이디 등이 이 소스코드를 사용한 파생물의 보증이나 홍보에 사용되어서는 안된다.

tips
==========
mingw stack option(40MB): -Wl,--stack,41943040

visual c++ stack option(16MB): #pragma comment(linker, "/STACK:16777216")

linux stacksize:

unlimited: ulimit -s unlimited

16MB: ulimit -s 16834


