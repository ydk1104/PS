#include<bits/stdc++.h>
#define ll long long
#define inf 1000000009
#define pii pair<int,int>
#define magic ios_base::sync_with_stdio(false);cin.tie(nullptr)
using namespace std;
#define forn(i,n) for(int i=1;i<=n;i++)
#define forRn(i,n) for(int i=n;i>=1;i--)
#define forz(i,n) for(int i=0;i<n;i++)
#define forRz(i,n) for(int i=n-1;i>=0;i--)
#define forab(i,a,b) for(int i=a;i<=b;i++)
#define forRab(i,a,b) for(int i=a;i>=b;i--)
#define mod 998244353

int main(void)
{
    magic;
    cout<<"A";
}
