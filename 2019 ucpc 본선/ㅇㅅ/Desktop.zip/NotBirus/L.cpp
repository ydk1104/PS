#include <bits/stdc++.h>
#define magic ios_base::sync_with_stdio(false);cin.tie(nullptr)
using namespace std;

int main() {
    magic;

    vector<int> a{1,1,2,3,5,8,13,21};

    for(auto& i : a) cout<< i <<' ';

    return 0;
}
