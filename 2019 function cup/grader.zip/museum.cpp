#include "museum.h"

long long CountSimilarPairs(std::vector<int> B, std::vector<int> T, std::vector<int> G) {
	int N = B.size();
	return 0;
}
