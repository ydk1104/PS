#include <vector>
long long CountSimilarPairs(std::vector<int> B, std::vector<int> T, std::vector<int> G);
