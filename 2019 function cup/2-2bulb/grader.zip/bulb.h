#include <vector>
int FindWinner(int T, std::vector<int> L, std::vector<int> R);
