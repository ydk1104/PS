#include "bulb.h"

int FindWinner(int T, std::vector<int> L, std::vector<int> R){
	int N = L.size();
	return 0;
}
