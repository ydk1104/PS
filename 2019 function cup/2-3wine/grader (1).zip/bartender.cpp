#include "bartender.h"

std::vector<int> BlendWines(int K, std::vector<int> R){
	int N = R.size();
	return R;
}
