#include "taster.h"

std::vector<int> SortWines(int K, std::vector<int> A) {
	int N = A.size();
	Compare(1, 2);
	return A;
}
