#include <vector>
int Compare(int P, int Q);
std::vector<int> SortWines(int K, std::vector<int> A);
