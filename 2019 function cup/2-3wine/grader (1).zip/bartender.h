#include <vector>
std::vector<int> BlendWines(int K, std::vector<int> R);

